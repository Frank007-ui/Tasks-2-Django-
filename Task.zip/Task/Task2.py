# Print numbers from 1 to 10

for i in range(1, 11):
    print(i)

# Print even numbers from 1 to 20 

for i in range(1, 21):
    if i % 2 == 0:
        print(i)  

# Print each item in a list

chocolates = ["DairyMilk", "5Star", "KitKat"]
for chocolate in chocolates:
    print(chocolate)

# Sum of numbers in a list 

numbers = [10, 20, 30, 40]
total = 0

for num in numbers:
    total += num

print("Total =", total) 

# Print multiplication table

num = 5
for i in range(1, 11):
    print(num, "X", i, "=", num * i)


# Print characters in a string

word = "Python"

for char in word:
    print(char)

# Find factorial of a number    

num = 5
fact = 1

for i  in range(1, num + 1):
    fact *= i
print("Factorial =", fact)   