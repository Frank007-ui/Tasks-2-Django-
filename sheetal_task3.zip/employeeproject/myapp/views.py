from django.shortcuts import render
from myapp.models import Employee

# Create your views here.
def view1(request):
    e=Employee.objects.all()
    cxt={'Emp':e}
    return render(request,'myapp/1.html',cxt)
