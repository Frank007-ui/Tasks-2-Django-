from django.db import models

# Create your models here.
class Employee(models.Model):
    ename=models.CharField(max_length=70)
    ejob=models.CharField(max_length=70)
    esal=models.FloatField()
    eplace=models.CharField(max_length=70)
    email=models.EmailField()
    edob=models.DateField()

    def __str__(self):
        return self.ename
