from django.urls import path
from . import views

urlpatterns = [
    path('', views.weather_report),  
    path('weather/', views.weather_report, name='weather'),
]

