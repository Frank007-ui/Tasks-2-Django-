from django.shortcuts import render

def weather_report(request):

    temperatures = [28, 31, 35, 40, 29, 22, 18]
    today = temperatures[0]

    if today >= 38:
        status = "Very Hot"
    elif today >= 30:
        status = "Warm"
    elif today >= 20:
        status = "Cool"
    else:
        status = "Cold"

    return render(request, "weather.html", {
        "temperatures": temperatures,
        "today": today,
        "status": status
    })
