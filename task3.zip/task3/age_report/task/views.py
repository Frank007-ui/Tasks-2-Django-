from django.shortcuts import render
def score_view(request):
    context = {'score': 85}
    return render(request, 'result.html', context)

