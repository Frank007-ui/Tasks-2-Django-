from django.urls import path
from . import views

urlpatterns = [
    path('',views.age_report),
    path('age/',views.age_report,name = 'age'),
]